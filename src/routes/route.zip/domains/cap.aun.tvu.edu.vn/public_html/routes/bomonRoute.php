<?php

use Illuminate\Support\Facades\Route;
Route::group(['middleware' =>'App\Http\Middleware\isBoMon'], function (){ 
    Route::group(['prefix' => 'bo-mon','namespace' => 'App\Http\Controllers\BoMon'], function () {
        Route::get('/', 'BMHomeController@index');
        //quản lý lớp AUN chính là lớp hành chính/lớp nhập học
        Route::group(['prefix' => 'quan-ly-lop'], function () {
            Route::get('/', 'BMlopController@index');
            Route::get('xem-danh-sach-sinh-vien/{maLop}', 'BMlopController@xem_danh_sach_sinh_vien');
            Route::post('cap-nhat-ds-sinh-vien-bang-excel', 'dsSinhVienImportController@import');
            Route::get('tai-file-mau', 'dsSinhVienImportController@download_template');
            Route::post('them-lop', 'BMlopController@addClass');
            Route::post('sua-lop', 'BMlopController@editClass');
            Route::get('xoa-lop/{maLop}', 'BMlopController@delClass');
            Route::post('them-sv-lop', 'BMlopController@them_sinh_vien_lop');
            Route::post('sua-sv-lop', 'BMlopController@sua_sinh_vien_lop');
            Route::get('xoa-sv-lop/{maSSV}', 'BMlopController@xoa_sinh_vien_lop');
        });
    
        
        //route phan cong giang day
       /*  Route::prefix('phan-cong-giang-day')->group(function () {
            Route::get('/','BMhocPhanController@index');
            Route::get('/{namHoc}','BMhocPhanController@xem_phan_cong_giang_day_theo_nam_hoc');
            Route::post('them-phan-cong-giang-day-submit', 'BMhocPhanController@them_hoc_phan_giang_day');
            Route::get('/xoa-hoc-phan-giang-day/{maHocPhan}/{maLop}/{maHKNH}','BMhocPhanController@xoa_hocphan_giangday');
            //Route::get('/xoa-hoc-phan-giang-day-don/{maHocPhan}/{maLop}/{maHK}/{namHoc}/{maGV}','BMhocPhanController@xoa_hocphan_giangday_gv');
            Route::get('/xem-danh-sach-sinh-vien/{maHocPhan}/{maLop}/{maHK}/{namHoc}','BMhocPhanController@xem_danh_sach_sinh_vien');
        }); */
    
        //route quản lý chương trình
        Route::group(['prefix' => 'quan-ly-chuong-trinh'], function () {
            Route::get('/', 'BMchuongTrinhController@index');
        });
         //route phan cong giang day
        Route::prefix('phan-cong-giang-day')->group(function () {
            Route::get('/','BMhocPhanController@index');
            //Route::get('/{namHoc}','BMhocPhanController@xem_phan_cong_giang_day_theo_nam_hoc');
            Route::post('them-phan-cong-giang-day-submit', 'BMhocPhanController@them_hoc_phan_giang_day');
            
            Route::get('/xoa-hoc-phan-giang-day/{maHocPhan}/{maLop}/{maHKNH}/{maGV}/{id}','BMhocPhanController@xoa_hocphan_giangday');
        // Route::get('/xoa-hoc-phan-giang-day-don/{maHocPhan}/{maNhomLop}/{maHKNH}/{maGV}','BMhocPhanController@xoa_hocphan_giangday_gv');
            Route::get('/xem-danh-sach-sinh-vien/{maHocPhan}/{maNhomLop}/{maHKNH}','BMhocPhanController@xem_danh_sach_sinh_vien');
            Route::get('/xem-chi-tiet-nhom-chung/{maHocPhan}/{maHKNH}/{maLop}','BMhocPhanController@xem_chi_tiet_nhom_chung');
            Route::get('/xem-chi-tiet-nhom/{id}','BMhocPhanController@xem_chi_tiet_nhom');
            //AUN quản lý nhóm lớp
            Route::group(['prefix' => 'nhom-lop'], function () {
                //Route::get('/', 'BMnhomlopController@index');
                Route::post('them-phan-cong-giang-day-nhom', 'BMnhomlopController@them_hoc_phan_giang_day_nhom');
                Route::post('them-phan-cong-giang-day-nhom-chung', 'BMnhomlopController@them_hoc_phan_giang_day_nhom_chung');
                Route::get('xem-danh-sach-sinh-vien-nhom-lop/{maNhomLop}', 'BMnhomlopController@xem_danh_sach_sinh_vien_nhom');
                Route::get('xem-danh-sach-sinh-vien-nhom-lop-chung/{maNhomLop}', 'BMnhomlopController@xem_danh_sach_sinh_vien_nhom_chung');
                Route::post('cap-nhat-ds-sinh-vien-nhom-lop-bang-excel', 'dsSinhVienNhomLopImportController@import');
                Route::post('cap-nhat-ds-sinh-vien-nhom-lop-chung-bang-excel', 'dsSinhVienNhomLopChungImportController@import');
                Route::get('tai-file-mau', 'dsSinhVienNhomLopImportController@download_template');
                //Route::post('them-nhom-lop', 'BMnhomlopController@addSubjectClass');
                Route::post('sua-nhom-lop', 'BMnhomlopController@editSubjectClass');
                Route::post('sua-nhom-lop-chung', 'BMnhomlopController@editSubjectClasschung');
                Route::get('xoa-nhom-lop/{maNhomLop}', 'BMnhomlopController@delSubjectClass');
                Route::get('xoa-nhom-lop-chung/{maNhomLop}', 'BMnhomlopController@delSubjectClasschung');
                //Route::post('them-sv-nhom-lop', 'BMnhomlopController@them_sinh_vien_nhom_lop');
                Route::post('sua-sv-nhom-lop', 'BMnhomlopController@sua_sinh_vien_nhom_lop');
                Route::get('xoa-sv-nhom-lop/{maNhomLop}/{maSSV}', 'BMnhomlopController@xoa_sinh_vien_nhom_lop');
                Route::get('xoa-sv-nhom-lop-chung/{maNhomLop}/{maSSV}', 'BMnhomlopController@xoa_sinh_vien_nhom_lop_chung');
            });
        });

        //route hoc phan
        Route::group(['prefix' => 'quan-ly-hoc-phan'], function () {
            Route::get('/{maCT}', 'BMhocPhanController@hoc_phan_theo_chuong_trinh');
            Route::post('/them-hoc-phan', 'BMhocPhanController@them_hoc_phan');
            Route::post('/sua-hoc-phan', 'hocPhanController@sua_hoc_phan');
            Route::group(['prefix' => 'quan-ly-de-cuong'], function () {
                ///bo-mon/quan-ly-hoc-phan/quan-ly-de-cuong/

                Route::post('them-ket-qua-hoc-tap-chuan-dau-ra','BMhocPhanController@them_ket_qua_hoc_tap_chuan_dau_ra');
                Route::post('sua_chuan_dau_ra_mon_hoc','BMhocPhanController@sua_chuan_dau_ra_mon_hoc');
                Route::get('/xoa_chuan_dau_ra_mon_hoc/{id}','BMhocPhanController@xoa_chuan_dau_ra_mon_hoc');
    
                Route::post('/them-chuong','BMhocPhanController@them_chuong_bai');
                Route::post('/sua-chuong','BMhocPhanController@sua_chuong_bai');
                Route::get('/xoa-chuong/{maChuong}','BMhocPhanController@xoa_chuong_bai');
    
                Route::post('/them-bai','BMhocPhanController@them_bai');
                Route::post('/sua-bai','BMhocPhanController@sua_bai');
                Route::get('/xoa-bai/{maBai}', 'BMhocPhanController@xoa_bai');
    
                Route::post('/them-danh-gia','BMhocPhanController@them_danh_gia');
                Route::post('/sua-danh-gia','BMhocPhanController@sua_danh_gia');
                Route::get('/xoa-danh-gia/{id}', 'BMhocPhanController@xoa_danh_gia');

                Route::post('/them-phieu-rubric','BMhocPhanController@them_rubric');
                Route::post('/sua-phieu-rubric','BMhocPhanController@sua_rubric');
                Route::get('/xoa-phieu-rubric/{maPhieuRubric}', 'BMhocPhanController@xoa_rubric');

                Route::prefix('tieu-chi-phieu-rubric')->group(function (){
                    Route::get('/{maPhieuRubric}','BMtieuchiphieuRubricController@index');
                    Route::post('/them-tieu-chi-phieu-rubric','BMtieuchiphieuRubricController@them');
                    Route::post('/sua-tieu-chi-phieu-rubric','BMtieuchiphieuRubricController@sua');
                    Route::get('/xoa-tieu-chi-phieu-rubric/{maTieuChiRubric}','BMtieuchiphieuRubricController@xoa');
                });
                Route::prefix('muc-do-chat-luong')->group(function () {
                    Route::get('/','BMmucdochatcluongController@index');
                    Route::post('/them-muc-do-chat-luong','BMmucdochatcluongController@them');
                    Route::post('/sua-muc-do-chat-luong','BMmucdochatcluongController@sua');
                    Route::get('/xoa-muc-do-chat-luong/{maMucDoCL}','BMmucdochatcluongController@xoa');
                });
                Route::get('/{maHocPhan}/{maKhoaTuyenSinh}', 'BMhocPhanController@quan_ly_de_cuong');

            });
        });
        
    });
});
